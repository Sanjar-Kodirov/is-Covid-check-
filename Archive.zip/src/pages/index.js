import AddPersonFormPage from "./AddPersonFormPage";
import Login from "./Login";
import PrintPage from "./PrintPage";
import Admin from "./Admin";
export { AddPersonFormPage, Admin, Login, PrintPage };
